// KuboOS 0.1 — layout predefinito
// Menu bar globale in alto (fissa) + dock che schiva le finestre (sinistra)

// --- sfondo su tutti i desktop
var ds = desktops();
for (var i = 0; i < ds.length; i++) {
    ds[i].wallpaperPlugin = "org.kde.image";
    ds[i].currentConfigGroup = ["Wallpaper", "org.kde.image", "General"];
    ds[i].writeConfig("Image", "file:///usr/share/wallpapers/KuboOS/");
}

// --- menu bar in alto
var bar = new Panel;
bar.location = "top";
bar.height = 28;
try { bar.floating = false; } catch (e) {}

// menu KuboOS: Kickoff (colonna categorie + elenco app) con pulsanti Platinum
var menu = bar.addWidget("org.kuboos.kickoff");
menu.currentConfigGroup = ["General"];
menu.writeConfig("icon", "kuboos");

bar.addWidget("org.kde.plasma.appmenu");
bar.addWidget("org.kde.plasma.panelspacer");
bar.addWidget("org.kde.plasma.systemtray");
var clock = bar.addWidget("org.kde.plasma.digitalclock");
clock.currentConfigGroup = ["Appearance"];
clock.writeConfig("showDate", "true");
clock.writeConfig("dateFormat", "shortDate");
clock.writeConfig("dateDisplayFormat", "BesideTime");

// --- dock
var dock = new Panel;
dock.location = "left";          // "left" | "right" | "bottom"
dock.height = 56;                // spessore: 48 px icona + margini
dock.hiding = "dodgewindows";    // si sposta quando una finestra lo copre
try { dock.floating = false; } catch (e) {}  // Platinum: niente pannelli fluttuanti con ombra
try { dock.lengthMode = "fit"; } catch (e) { dock.alignment = "center"; }

var tasks = dock.addWidget("org.kde.plasma.icontasks");
tasks.currentConfigGroup = ["General"];
tasks.writeConfig("launchers", [
    "applications:calamares-install-debian.desktop",
    "applications:org.kde.dolphin.desktop",
    "applications:firefox-esr.desktop",
    "applications:org.kde.konsole.desktop",
    "applications:org.kde.kate.desktop",
    "applications:org.kde.discover.desktop",
    "applications:kuboos-steam.desktop",
    "applications:systemsettings.desktop"
].join(","));
tasks.writeConfig("iconSpacing", "1");
tasks.writeConfig("maxStripes", "1");
