[Appearance]
ColorScheme=KuboOS
Font=DejaVu Sans Mono,10,-1,5,400,0,0,0,0,0,0,0,0,0,0,1
AntiAliasFonts=true
UseFontLineChararacters=true

[Cursor Options]
CursorShape=0

[General]
Name=KuboOS
Parent=FALLBACK/
TerminalMargin=4

[Scrolling]
HistoryMode=2
